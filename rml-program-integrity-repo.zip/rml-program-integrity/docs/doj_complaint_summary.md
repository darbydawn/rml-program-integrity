# DOJ Criminal Complaint Summary
## United States v. Munster and Kwe
### Eastern District of Michigan | Unsealed June 2, 2026

---

## Defendants

**Vincent Munster**
- Age: 53
- Citizenship: Netherlands
- Title: Chief, Virus Ecology Section, Laboratory of Virology
- Employer: NIH/NIAID, Rocky Mountain Laboratories, Hamilton, MT
- Research focus: Emerging viral pathogens, cross-species transmission
- Notable: 2018 DARPA PREEMPT award recipient; DEFUSE Project partner; co-author on Egyptian fruit bat/Wuhan coronavirus study

**Claude Kwe Yinda**
- Age: 38
- Citizenship: Cameroon
- Title: Research Fellow, Virus Ecology Section
- Employer: NIH/NIAID, Rocky Mountain Laboratories, Hamilton, MT

---

## Charges

1. Conspiracy to smuggle monkeypox into the United States
2. Making false statements to federal law enforcement (18 U.S.C. 1001)

Maximum sentence: 5 years per count

---

## Key Facts from Complaint

**January 25, 2026:** Munster and Kwe arrived at Detroit Metropolitan Airport (McNamara Terminal) after a flight from Paris with travel originating from Brazzaville, Republic of Congo. An mpox outbreak was active in Congo at the time.

**CBP inspection:** Officers observed the pair traveling with a large black plastic case. When questioned, Munster and Kwe told CBP the case contained "diagnostics and testing equipment."

**What was actually in the case:** 113 vials packed in Styrofoam coolers. FBI testing of 20 vials revealed:
- 17 vials: deactivated monkeypox virus
- 1 vial: chickenpox virus
- 2 vials: human DNA only

**Munster's statement to investigators:** When asked for documentation, Munster stated the required documents were on his laptop, then said: **"but you don't need them. I do this all the time."**

**Munster's denial:** Munster "adamantly denied" returning to the U.S. with biological materials or samples. Physical evidence contradicted this.

**FBI finding:** "It is reasonable to believe that Munster's statements regarding the possession of the required documentation to [customs officers] were materially false."

**Regulatory violation:** USDA APHIS confirmed Munster and Kwe required a permit under 9 CFR Part 122 to import the biological materials. Neither man possessed the required permit.

**Complaint language:** "Munster and Kwe did not present the true identities of the biological materials in their possession and did not provide or possess the necessary certifications. Rather, Munster and Kwe attempted to pass the samples off as unused diagnostics."

---

## Investigating Agencies

- FBI Detroit Field Office (Joint Terrorism Task Force)
- FBI Billings / Missoula Resident Agency
- U.S. Customs and Border Protection, Detroit
- **HHS Office of Inspector General** (notable: OIG involvement signals federal program integrity concern beyond simple customs violation)

---

## Prosecuting Office

U.S. Attorney's Office, Eastern District of Michigan
U.S. Attorney: Jerome F. Gorgon Jr.

**Note:** Defendants expected to appear in federal court in Missoula, Montana -- the district that covers Hamilton, MT (home of RML).

---

## Prior Incidents at RML (Documented Pre-Arrest)

Per Senate oversight letter (Ernst, November 2023) and Senator Sheehy HHS-OIG investigation request (May 2026):

1. Lassa fever-infected mouse escaped containment; CDC not promptly notified as required
2. Unauthorized individuals including a child accessed the RML primate facility
3. Two "theft, loss, or release of a pathogen" incidents acknowledged by NIH in the year prior to Munster/Kwe arrest
4. February 2026: RML employee potentially exposed to Crimean-Congo Hemorrhagic Fever (CCHF) due to hole in personal protective equipment

---

## The "I Do This All the Time" Statement: Significance

This single statement is the most significant program integrity finding in the complaint because it transforms a single incident into evidence of a pattern.

If Munster routinely transported biological samples from international field sites without required USDA APHIS permits, then:

1. Every prior field trip conducted under federal research authorization involved the same regulatory violation
2. Each prior trip represents a potential separate count of false implied certification
3. The institutional culture at RML -- specifically in Munster's lab -- normalized non-compliance with federal biosafety transport regulations
4. NIH/NIAID leadership either knew or should have known this was occurring

This is the same analytical framework used in qui tam FCA cases: the statement of a single individual reveals a systemic pattern, which multiplies both liability exposure and the number of potential false claims.

---

## Status as of June 3, 2026

- Criminal complaint unsealed June 2, 2026
- Defendants expected to appear in Missoula federal court June 4, 2026
- 93 vials not yet tested as of complaint filing date
- HHS-OIG investigation active and ongoing
- NIH cooperating with law enforcement; declined further comment
- All active NIH contracts at RML continue without documented modification
