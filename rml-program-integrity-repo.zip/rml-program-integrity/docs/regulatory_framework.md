# Regulatory Framework: RML Biosafety Compliance and FCA Nexus

## Key Federal Regulations

### 9 CFR Part 122 -- USDA APHIS Import Permits
The criminal complaint cites this regulation directly. It mandates that:
> "No organisms or vectors shall be imported into the United States or transported from one State or Territory or the District of Columbia to another...without a permit."

Monkeypox virus, classified as a select agent by HHS, requires a USDA APHIS import permit for any transport into the United States. This includes deactivated samples. Munster and Kwe did not possess the required permit when they arrived at Detroit Metropolitan Airport on January 25, 2026.

### 42 CFR Part 73 -- HHS Select Agent Regulations
Monkeypox is a Tier 1 select agent under HHS/CDC regulations. 42 CFR Part 73 governs:
- Registration requirements for entities possessing select agents
- Transfer and transport requirements
- Biosafety and biosecurity plans
- Incident reporting requirements

Separate from the USDA import permit requirement, select agent regulations impose additional compliance obligations on registered entities like RML.

### 31 U.S.C. § 3729 -- The False Claims Act
The FCA imposes liability on any person who:
- Knowingly presents a false or fraudulent claim for payment to the United States
- Knowingly makes or uses a false record or statement material to a false claim
- Knowingly makes or uses a false record material to an obligation to pay the government

**The false certification theory:** When a party receives federal funds conditioned on compliance with applicable law or regulations, and certifies such compliance while actually non-compliant, each false certification constitutes a false claim.

### P.L. 116-136 -- CARES Act (March 2020)
The Coronavirus Aid, Relief, and Economic Security Act appropriated emergency funds for COVID-19 response. DEFC Code "N" in USASpending designates awards funded under this emergency authorization. Recipients must certify that funds are used for authorized COVID response purposes.

---

## The FCA Argument Applied to RML

### Theory 1: False Certification of USDA APHIS Compliance

**Facts established:**
- Munster and Kwe conducted field research in Africa under NIH research authorization
- They returned with biological materials without required USDA APHIS import permits
- Munster stated "I do this all the time" -- implying a pattern of prior non-compliant transport
- FBI stated it was "reasonable to believe" Munster's statements about documentation were "materially false"

**FCA nexus:**
NIH intramural research operates under federal authorization that requires compliance with all applicable federal laws and regulations, including biosafety and import/export requirements. Each field trip conducted under federal research authorization, with samples imported without required USDA APHIS permits, involves an implicit or explicit certification of regulatory compliance. If Munster regularly transported samples without permits, each prior trip may constitute a separate false certification.

This is not a stretch -- it mirrors established FCA cases involving research institutions where grantees certified compliance with human subjects protections or data integrity requirements while actually non-compliant.

### Theory 2: CARES Act False Certification

**Facts established:**
- $100,755,913 in CARES Act emergency funds (DEFC N, P.L. 116-136) were used to construct Building B Vivarium at RML
- The facility houses bats, rodents, ticks, and exotic species at BSL-2 level
- NIH justified this as expanding "COVID-19 research capabilities"
- Senator Ernst raised this issue with NIH in November 2023; no adequate response documented
- The lab simultaneously had documented biosafety compliance failures

**FCA nexus:**
Emergency appropriations require certification that funds are used for authorized emergency purposes. The connection between a BSL-2 bat vivarium and COVID emergency response is tenuous. If NIH certified this construction as emergency COVID spending without adequate basis, and the lab was simultaneously operating outside biosafety regulatory requirements, the certification may be materially false.

This theory is strengthened by the pre-existing pattern of biosafety non-compliance -- the same institutional culture that allowed Munster to transport samples without permits for years was operating while federal officials certified CARES Act compliance.

### Theory 3: Prior Incident Non-Reporting

**Facts established:**
- A Lassa fever-infected mouse escaped containment; CDC was not promptly notified as required
- RML officials "did not believe they needed to report" the incident until instructed by CDC
- NIH acknowledged two "theft, loss, or release of a pathogen" incidents in the year prior to the Munster/Kwe arrest
- Senator Sheehy cited these incidents in his HHS-OIG investigation request

**FCA nexus:**
Select agent regulations require prompt incident reporting to CDC. Failure to report incidents as required, while continuing to receive federal funding contingent on regulatory compliance, may constitute additional false certifications.

---

## Precedent Cases

**United States ex rel. Hendow v. University of Phoenix (9th Cir. 2006)**
Established that false certifications of compliance with statutory and regulatory requirements constitute false claims under the FCA.

**United States v. Science Applications International Corp. (D.C. Cir. 2011)**
Held that a contractor's continued performance under a contract while failing to comply with safety requirements -- and submitting invoices for payment -- constitutes false implied certifications.

**Universal Health Services v. United States ex rel. Escobar (U.S. 2016)**
Supreme Court confirmed the implied false certification theory: submitting a claim for payment while concealing non-compliance with conditions material to payment constitutes a false claim.

The Escobar materiality standard requires that the false certification be material to the government's decision to pay. Here, NIH/NIAID compliance with biosafety regulations and CARES Act spending restrictions is clearly material to the government's decision to fund RML operations.

---

*Document prepared for portfolio purposes. Not legal advice.*
