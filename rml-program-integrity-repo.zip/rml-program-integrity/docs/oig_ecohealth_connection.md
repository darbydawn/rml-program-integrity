# OIG Audit Report A-05-21-00025 -- Connection to RML
## "NIH and EcoHealth Alliance Did Not Effectively Monitor Awards and Subawards"
### January 25, 2023 | HHS-OIG Inspector General Christi A. Grimm

---

## The Report

**Official title:** "The National Institutes of Health and EcoHealth Alliance Did Not 
Effectively Monitor Awards and Subawards, Resulting in Missed Opportunities to 
Oversee Research and Other Deficiencies"

**Scope:** Three NIH awards to EcoHealth totaling approximately $8.0 million, 
including $1.8 million in subawards to eight subrecipients, including the 
Wuhan Institute of Virology (WIV). Audit period: FY2014-FY2021.

**Awarding agency:** NIAID -- the same institute that directly funds Munster 
and de Wit's intramural research at RML.

---

## Key Findings from the Report

**NIH failed to effectively monitor EcoHealth's compliance:**
- NIH did not take timely action to address EcoHealth's non-compliance
- NIH failed to follow up on a progress report for nearly 2 years after its due date
- NIH failed to properly refer research for enhanced potential pandemic pathogen (ePPP) review
- NIH improperly terminated a grant
- EcoHealth could not obtain scientific documentation from WIV
- $89,171 in unallowable costs identified

**The oversight failure:**
> "NIH missed opportunities to more effectively monitor research. With improved 
> oversight, NIH may have been able to take more timely corrective actions to 
> mitigate the inherent risks associated with this type of research."

**The foreign subrecipient problem:**
> "Compounding these longstanding challenges are risks that may limit effective 
> oversight of foreign subrecipients, which often depends on cooperation between 
> the recipient and subrecipient, and the countries in which the research is performed."

---

## The RML-EcoHealth Connection

This is not an abstract organizational connection. The Senate Ernst letter 
(November 2023) and published research confirm:

**1. Active collaboration confirmed by NIH itself:**
As recently as 2022, RML cited EcoHealth Alliance as an active collaborator 
on research on cross-species transmission of coronaviruses from bats and 
other deadly pathogens.

**2. Munster co-authored the Egyptian fruit bat/WIV coronavirus study:**
Munster was lead author on a 2018 paper infecting Egyptian fruit bats 
(procured from a Maryland zoo near Camp David) with WIV1-CoV, a SARS-like 
bat coronavirus originally isolated from Chinese horseshoe bats and 
associated with the Wuhan Institute of Virology. EcoHealth's Peter Daszak 
was a collaborator on this research ecosystem.

**3. Munster co-authored the DEFUSE proposal:**
Munster was listed as a partner in the DEFUSE Project proposal to DARPA 
(2018), which proposed inserting a furin cleavage site into bat viruses. 
DARPA denied funding. The Chinese side proceeded independently.

**4. Munster helped EcoHealth secure the "Wuhan West" bat lab at Colorado State:**
In 2021, Munster wrote a letter of support for EcoHealth/CSU's NIAID 
application to establish a bat colony at Colorado State University, stating: 
"Dr. Munster will facilitate the establishment of the colony, and will be 
the laboratory lead and co-investigator on all experimental studies utilizing 
these bats. We will have the support and use of the BSL-4 laboratory and 
veterinary personnel at RML for experimental work."

**5. Privately, Munster acknowledged waste while publicly endorsing:**
White Coat Waste obtained documents showing Munster privately acknowledged 
"tens of millions wasted" on EcoHealth bat virus-hunting and dead-end animal 
tests, while simultaneously asking NIAID to fund him and EcoHealth millions 
for new bat lab work at CSU.

---

## Why This Matters for Program Integrity

The OIG audit was published **January 25, 2023** -- exactly **three years** 
before Munster's arrest at Detroit airport on **January 25, 2026**.

On the day the OIG published its finding that NIAID failed to effectively 
monitor research involving the same collaborative network as Munster's lab, 
Munster's "International Research in Congo" project (ZIA AI001190) was in 
its 9th year of continuous funding. He had been conducting annual Congo 
field trips since FY2014 -- allegedly without required USDA APHIS import 
permits the entire time.

**The oversight failure documented in the OIG report is the same 
oversight failure that allowed the Congo non-compliance to continue 
for 12 years undetected.**

NIAID -- the awarding body -- was simultaneously:
1. Failing to monitor EcoHealth's compliance with grant requirements (OIG finding)
2. Funding Munster's Congo field research annually without apparent biosafety
   transport permit verification (criminal complaint)
3. Funding the CARES Act vivarium construction at the same facility
4. Receiving and ignoring biosafety incident reports at RML

This is not two separate failures. This is one institutional culture of 
inadequate oversight documented in a federal audit three years before it 
produced criminal charges.

---

## The Network: Connected Oversight Failures

```
NIAID (awarding/oversight body)
    │
    ├── EcoHealth Alliance (grantee)
    │       └── WIV subrecipient
    │       └── CSU bat lab (Munster co-investigator)
    │       └── OIG finding: oversight failure FY2014-2021
    │
    └── RML / Munster lab (intramural)
            └── Congo field research (12 years, ZIA AI001190)
            └── DEFUSE collaboration
            └── WIV coronavirus bat research (2018 paper)
            └── Criminal charges January 2026
            └── de Wit co-investigator (same facility)
```

NIAID is the common node. The OIG documented NIAID's oversight failure 
of the EcoHealth network in January 2023. The criminal complaint documents 
NIAID's failure to oversee its own intramural researcher in June 2026. 
Same agency. Same oversight culture. Same research ecosystem.

---

## Additional Network Finding: Ralph Baric Connection

Munster co-authored papers with Ralph Baric (UNC), who recently retired 
after being removed from NIH grants. Baric is the central figure in 
gain-of-function bat coronavirus research. Munster's bat research used 
WIV1-CoV from the same lineage as Baric's work. NIH removed Baric from 
grants; Munster continued to be funded and conduct field work until arrest.

---

## Timeline of Prior Notice to NIAID

| Date | Event |
|------|-------|
| FY2014 | Munster Congo project (ZIA AI001190) established |
| 2014 | RML biosafety incidents first publicly reported (Bozeman Daily Chronicle) |
| 2014-2021 | OIG audit period -- EcoHealth/NIAID oversight failures |
| 2018 | Munster DARPA PREEMPT awards -- compliance certifications required |
| 2021 | RML Lassa fever mouse escape -- CDC not promptly notified |
| Jan 25, 2023 | OIG publishes A-05-21-00025 -- NIAID oversight failure documented |
| Nov 2023 | Senate Ernst letter to NIH about RML/EcoHealth/bat research |
| Jan-Apr 2024 | Munster Congo field work (Lancet paper -- Brazzaville samples) |
| FY2025 | Congo project funded for 12th consecutive year ($358,773) |
| Jan 25, 2026 | Munster/Kwe arrested at Detroit airport -- 113 vials, no permits |
| Jun 2, 2026 | Criminal complaint unsealed |

NIAID had prior notice of biosafety failures at RML going back to at least 2014. 
OIG documented NIAID's oversight failures in the same research ecosystem in 2023. 
The criminal charges filed in 2026 represent the foreseeable consequence of 
uncorrected institutional oversight failures spanning more than a decade.

---

*Document prepared for portfolio purposes. Not legal advice.*
*Author: Dawn Krysa, PA-C, MSHIIM, CHDA | github.com/darbydawn*
