# Rocky Mountain Laboratories: Federal Spending & Program Integrity Analysis

**Author:** Dawn Krysa, PA-C, MSHIIM, CHDA  
**Repository:** Phase 6 of Healthcare Fraud in America: FCA Settlement Analysis  
**Date:** June 2026  
**Status:** Active investigation

---

## Background

On June 2, 2026, the U.S. Department of Justice unsealed a criminal complaint against two NIH researchers at Rocky Mountain Laboratories (RML) in Hamilton, Montana:

- **Vincent Munster**, 53, Dutch national, Chief of the Virus Ecology Section, Laboratory of Virology
- **Claude Kwe**, 38, Cameroonian national, Research Fellow

Charges: Conspiracy to smuggle monkeypox (mpox) into the United States and making false statements to federal law enforcement (18 U.S.C. 1001).

On January 25, 2026, both men arrived at Detroit Metropolitan Airport from Brazzaville, Republic of Congo -- where a monkeypox outbreak was active -- carrying 113 vials in Styrofoam coolers inside a black plastic case. When questioned by CBP officers, they claimed the case contained "diagnostics and testing equipment." Testing revealed 17 of 20 sampled vials contained deactivated monkeypox virus. Munster told investigators the required documentation was on his laptop, adding: **"but you don't need them. I do this all the time."**

Federal investigators determined Munster and Kwe lacked the required USDA APHIS permit (9 CFR Part 122) to import biological materials. HHS-OIG is an active investigating agency on the case alongside FBI and CBP.

---

## Research Questions

1. How much federal money has flowed to RML and ZIP 59840 (Hamilton, MT)?
2. Were any funds -- particularly COVID emergency appropriations -- misused or improperly certified?
3. Does the pattern of biosafety non-compliance at RML constitute a False Claims Act exposure?
4. What does the full federal spending picture reveal about systemic oversight gaps?

---

## Key Findings

### Finding 1: $100.8M in CARES Act Funds for Animal Research Construction

Contract 75N99022F00001 (Hensel Phelps Construction Co.) obligated **$100,755,913** under DEFC Code "N" -- Emergency P.L. 116-136 (CARES Act) -- for construction of the Building B Vivarium at RML. The facility houses bats, rodents, ticks, and exotic species at BSL-2 level. NIH justified this as expanding "COVID-19 research capabilities."

The CARES Act was passed for pandemic emergency response. Using emergency COVID funds to build permanent exotic species animal housing is a potential misuse of emergency appropriations. Senator Joni Ernst raised this issue directly with NIH Director Bertagnolli in November 2023; NIH's response was inadequate.

**FCA relevance:** Federal agencies certify that CARES Act expenditures serve authorized COVID response purposes. If that certification is false or materially misleading, it may constitute a false claim under 31 U.S.C. § 3729.

### Finding 2: $737M in Total Contract Obligations to ZIP 59840

- Total NIH obligations: **$632,635,520**
- Total COVID supplemental obligated: **$102,839,257**
- Active contracts post-arrest (Jan 25, 2026): **$142,012,547**
- Contracts with $0 outlayed despite completion: **$193,276,940** (data quality gap)

### Finding 3: $142M in Active Contracts with No Post-Arrest Review

13 NIH contracts totaling $142M remained active after the January 25, 2026 arrest date with no documented pause, modification, or review. The largest is Hensel Phelps 75N99024F00002 at $127.5M, running through October 2027.

### Finding 4: Prior Biosafety Failures Predating Current Charges

Senate oversight documentation confirms prior incidents at RML:
- Lassa fever-infected mouse escaped containment; CDC not promptly notified
- Unauthorized individuals including a child accessed the primate facility
- Two "theft, loss, or release of a pathogen" incidents acknowledged by NIH in the year prior to the Munster/Kwe arrest
- Biosafety compliance failures going back to at least 2014

**FCA relevance:** The "I do this all the time" statement implies a pattern of prior non-compliant transport. Each prior trip conducted under federal research authorization, with samples imported without required USDA APHIS permits, may constitute a separate false certification.

### Finding 5: Contractor Concentration

Jackson Contractor Group (Missoula, MT) holds **104 contracts** totaling **$54,987,067** -- 8.7% of all NIH contract spend at RML. This concentration warrants review of competitive bidding compliance.

### Finding 6: Cape Fox Facilities Services -- ANC Set-Aside Jump

Security guard contracts jumped from $2.4M to $18M between awards to Cape Fox, an Alaska Native Corporation with set-aside contracting authority. The prior $2.4M contract shows $0 in outlays despite a completed performance period.

---

## The FCA Framework

The False Claims Act (31 U.S.C. § 3729) imposes liability on any person who:
- Knowingly presents a false or fraudulent claim for payment
- Knowingly makes or uses a false record or statement material to a false claim
- **Knowingly makes or uses a false record material to an obligation to pay the government**

The **false certification theory** applies here: when federal employees or contractors certify compliance with applicable regulations as a condition of receiving or retaining federal funds, a false certification of compliance is a false claim.

Munster's statement -- "I do this all the time" -- suggests repeated non-compliant transport of biological materials under federal research authorization, each instance accompanied by implicit certification of regulatory compliance. The USDA APHIS permit requirement (9 CFR Part 122) is not optional or obscure; it is a baseline regulatory requirement for BSL-4 researchers conducting international field work.

---

## Data Sources

| File | Source | Records | Total Obligated |
|------|--------|---------|----------------|
| contracts_rml_59840.csv | USASpending.gov | 3,743 | $737,622,338 |
| assistance_rml_59840.csv | USASpending.gov | 1,674 | $64,811,856 |

**Additional sources needed:**
- NIH RePORTER: Munster/Kwe intramural project records
- CDC Select Agent Program: RML registration and inspection history
- USDA APHIS: Permit records (or absence thereof) for RML field trips
- DOJ PACER: Full criminal complaint (Eastern District of Michigan, unsealed June 2, 2026)
- HHS-OIG: Prior audit reports on NIAID/RML
- Senate Ernst letter response from NIH (November 2023)

---

## Repository Structure

```
rml-program-integrity/
├── README.md                          # This file
├── data/
│   ├── contracts_rml_59840.csv        # USASpending contracts download
│   └── assistance_rml_59840.csv       # USASpending assistance download
├── analysis/
│   ├── spending_analysis.py           # Financial overview and flags
│   ├── covid_funds_analysis.py        # CARES Act spending deep dive
│   └── contractor_concentration.py   # Competitive bidding analysis
├── docs/
│   ├── regulatory_framework.md        # 9 CFR 122, 42 CFR 73, FCA nexus
│   ├── doj_complaint_summary.md       # Criminal complaint key facts
│   └── fca_analysis.md               # False certification argument
└── outputs/
    ├── rml_spending_overview.png
    ├── covid_funds_breakdown.png
    └── contractor_concentration.png
```

---

## Connection to Prior FCA Portfolio Work

This repository is Phase 6 of a multi-phase FCA analysis project:

- Phase 1: Medicaid T-MSIS anomaly detection (1,109 flagged records, 2 confirmed OIG referrals -- both DOJ-charged defendants)
- Phase 2: Medicare physician utilization, Arizona amniotic allograft cluster ($452M+ exposure)
- Phase 3: DOJ FCA cross-reference (71% defendant confirmation rate)
- Phase 4: OIG LEIE national exclusion analysis (83,001 records)
- Phase 5: Tableau dashboard (planned)
- **Phase 6: RML federal biosafety and program integrity (this repository)**

---

## Disclaimer

This analysis is based entirely on publicly available federal data and publicly reported court documents. All findings are preliminary and subject to revision. This is independent research for portfolio purposes only. The defendants are presumed innocent until proven guilty.

*Dawn Krysa, PA-C, MSHIIM, CHDA -- github.com/darbydawn*
