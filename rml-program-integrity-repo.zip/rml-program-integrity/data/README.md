# Data Sources

## Files in this directory

### contracts_rml_59840.csv
- **Source:** USASpending.gov
- **Download URL:** https://www.usaspending.gov/search?hash=9e2f8ba8d3e2f2a0426a208be9f4a6ee
- **Date downloaded:** June 3, 2026
- **Filter applied:** Place of Performance ZIP code 59840 (Hamilton, MT)
- **Award type:** Contracts (Prime Award Summaries)
- **Records:** 3,743
- **Total obligated:** $737,622,338

### assistance_rml_59840.csv
- **Source:** USASpending.gov
- **Download URL:** https://www.usaspending.gov/search?hash=9e2f8ba8d3e2f2a0426a208be9f4a6ee
- **Date downloaded:** June 3, 2026
- **Filter applied:** Place of Performance ZIP code 59840 (Hamilton, MT)
- **Award type:** Assistance (Grants, Direct Payments, Loans)
- **Records:** 1,674
- **Total obligated:** $64,811,856

## How to reproduce

1. Go to https://www.usaspending.gov/search
2. Under Location, select "Place of Performance" and enter ZIP code **59840**
3. Click Search
4. To download contracts: click the Contracts tab, then Download
5. To download assistance: click the Grants/Direct Payments tabs, then Download

## NIH RePORTER Data

Munster and de Wit intramural project data was manually collected from:
https://reporter.nih.gov

Search terms used:
- PI Name: "Munster, Vincent" -- returned ZIA AI001179, AI001190, AI001289
- PI Name: "de Wit, Emmie" -- returned ZIA AI001259, AI001288

## Notes

- ZIP 59840 covers Hamilton, MT and surrounding Ravalli County
- Not all records in this ZIP are RML-related -- Forest Service, DOT,
  housing, and farm program records are also included
- Filter by awarding_sub_agency_name = "National Institutes of Health"
  to isolate RML-specific contract spending
- COVID supplemental funds identified by DEFC codes N and L
  (Emergency P.L. 116-136 CARES Act and Emergency P.L. 116-123)
